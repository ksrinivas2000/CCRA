# CCRA FANET simulation (ns-3.31, Python)

Implements the manuscript *"An Integrated Approach for Load-Balanced Cluster Head
Selection, Super Cluster Head Selection, and Routing in FANET"*:

| Step | Manuscript | File |
|---|---|---|
| FANET (UAVs, BS, WiFi, mobility, traffic) | Sec. 3, Table 1 | `ns3_engine.py` |
| Adaptive clustering | Sec. 4.1, Eq. 1-6, Alg. 1 | `adaptive_clustering.py` |
| Load-balanced CH selection, fitness | Sec. 4.2, Eq. 7-22, Fig. 3 | `ch_selection.py` |
| CCRA optimiser (proposed) | Eq. 23-44, Alg. 2 | `optimizers/ccra.py` |
| SCH selection (Mamdani FIS) | Sec. 4.3, Eq. 45-50 | `sch_fuzzy.py` |
| Multi-agent actor-critic routing, trained by the optimiser | Sec. 4.4 | `routing_maac.py` |
| Energy model (50 nJ/bit) | Table 1 | `energy_model.py` |
| One simulation run | | `fanet_sim.py` |
| Vary nodes and rounds, summarise, plot | | `run_experiments.py`, `plot_results.py` |
| All parameters | Table 1 | `config.py` |

## Optimisation files (one per method)

```
optimizers/pso.py    Particle Swarm Optimisation         (baseline)
optimizers/gwo.py    Grey Wolf Optimiser                  (baseline)
optimizers/cco.py    Cuckoo Catfish Optimizer             (Eq. 25-44 without DRA)
optimizers/dra.py    Divine Religions Algorithm
optimizers/ccra.py   CCRA = CCO + DRA (Eq. 32)            (proposed)
```
All share `optimize(fitness, dim, lb, ub, pop_size, max_iter, rng)` and minimise.
For each run, the chosen optimiser is used for both CH selection and training the routing actor.
To add a method, drop a file with the same `optimize` function into `optimizers/` and register it in `optimizers/__init__.py`.

## 1. Build ns-3.31 with Python bindings

```bash
cd ns-allinone-3.31/ns-3.31
pip3 install pybindgen==0.21.0          # version expected by ns-3.31
./waf configure --enable-python-bindings --enable-examples
./waf build
./waf shell                              # then: python3 -c "import ns.core; print('ok')"
```
`./waf configure` must report **Python Bindings: enabled**. If it doesn't, install `python3-dev`
and `castxml`, then reconfigure.

## 2. Copy the code

```bash
cp -r ccra_fanet  ns-3.31/scratch/ccra_fanet
pip3 install numpy pandas matplotlib
```

## 3. Single run

```bash
cd ns-3.31
./waf --pyrun "scratch/ccra_fanet/fanet_sim.py --nodes 100 --rounds 500 --method CCRA"
```
Output: `results/raw/rounds_CCRA_N100_seed1_ns3.csv` (one row per round), plus topology
snapshots for rounds 20 and 50 (`SNAPSHOT_ROUNDS` in `config.py`).

## 4. Full grid: vary number of nodes and number of rounds

```bash
cd ns-3.31
python3 scratch/ccra_fanet/run_experiments.py --ns3-dir . \
    --nodes 50 100 150 200 \
    --rounds 100 200 300 400 500 \
    --methods PSO GWO CCO DRA CCRA \
    --seeds 1 2 3 --jobs 4 --out results
```
* Each (nodes, method, seed) runs once up to the largest round count. Metrics are then
  summarised at every round count you list, so you don't need separate runs per round value.
* `results/summary_vs_rounds.csv`: metrics for each method × nodes × rounds.
* `results/summary_vs_nodes.csv`: metrics for each method × nodes at the final round.
* `results/plots/`: `<metric>_vs_rounds_N<n>` and `<metric>_vs_nodes_R<r>` as PNG, SVG and CSV,
  plus `topology_*.png` (Fig. 4 style: green UAVs, blue CHs, orange SCH, BS triangle, red routes).
* With several seeds, the summaries are seed means and `summary_vs_rounds_std.csv` holds the
  standard deviations. Use these for error bars or confidence intervals.

Metrics (Sec. 5.2): energy (J), delay (ms), distance (m), node degree, link lifetime (s), ICC,
plus PDR, throughput, alive nodes and load-balance factor.

**Runtime:** with the Table 1 settings (population 30, 100 iterations), the Python controller
takes about 0.6 s per round plus about 10 s per routing re-training. That's roughly 9 min per
500-round run before ns-3's own simulation time. Use `--jobs` to run in parallel. For a quick
check, add `--pop 10 --iters 20`.

## 5. Test without ns-3

```bash
python3 fanet_sim.py --engine python --nodes 50 --rounds 20 --method CCRA
python3 run_experiments.py --engine python --nodes 40 80 --rounds 10 20 --pop 10 --iters 15
```
The python engine reproduces the controller logic, but its radio and mobility model is a
simplification. Every row it writes is tagged `engine=python`, and plots get a `_python`
suffix. **Do not report those numbers as ns-3 results.**

## Notes and decisions to check

1. **Eq. (27)/(32) uses cos(π/2) = 0.** As written, the CCRA hybrid step gives a = 0 and the
   new position ≈ 0, so it acts as a jump to the lower bound that Eq. (44) usually rejects.
   `CCRA_LITERAL_EQ32 = True` (default) implements the equation exactly as written. Setting it
   to `False` uses cos(π/2·ℜ) and keeps the current position. Whichever you choose, the
   manuscript equation should state it, because reviewers can check this algebra.
2. **CCO and DRA symbols.** The manuscript doesn't define several CCO and DRA symbols
   numerically (helix coefficients, shrink factor, chaotic coefficient, the DRA proselytism
   step). The choices made are documented at the top of `cco.py` and `dra.py`. Compare them
   with the original authors' code if exact replication matters.
3. **Fitness normalisation.** Eqs. 7-21 are normalised to [0, 1] and oriented so that Eq. 22
   is maximised. Where an equation's literal direction conflicted with its "(max)/(min)"
   label, the label was followed. Each choice is commented in `ch_selection.py`.
4. **Routing network size.** Table 1 lists 512 hidden neurons. The actor's weights are searched
   by the metaheuristic, and 512 hidden units gives about 5,000 dimensions, which population 30
   × 100 iterations can't search well. The default is therefore `ROUTE_HIDDEN = 16`. Set it to
   512 to match the table exactly; it will run, but more slowly. Either way, the paper's table
   should state the value actually used.
5. **Energy.** Energy is computed with the first-order radio model (Table 1's 50 nJ/bit) from
   the packets and hop distances of each round. ns-3's energy framework isn't used. Delay, PDR
   and throughput come from ns-3 FlowMonitor.
6. **Traffic.** By default each source sends 2 packets per 2 s round (`PKTS_PER_ROUND`,
   `ROUND_TIME`), which keeps the 1 Mbps channel from saturating at 200 nodes. With 100 J
   initial energy, no UAV dies within 500 rounds. To study network lifetime, lower
   `INITIAL_ENERGY` or raise the traffic.

"""First-order radio energy model (E_elec = 50 nJ/bit from Table 1)."""
import numpy as np


def tx_energy(bits, d, cfg):
    d0 = np.sqrt(cfg.EPS_FS / cfg.EPS_MP)
    amp = np.where(d < d0, cfg.EPS_FS * d ** 2, cfg.EPS_MP * d ** 4)
    return cfg.E_ELEC * bits + amp * bits


def rx_energy(bits, cfg):
    return cfg.E_ELEC * bits


def round_energy(n_total, flows, paths, D, ctrl, cfg, aggregators):
    """
    flows : list of dicts (src, dst, pkts, bytes)
    paths : list of node paths (same order as flows)
    ctrl  : dict global node -> (n_ctrl_tx, degree) for clustering control messages
    aggregators : set of nodes that aggregate received data (CHs and SCH)
    Returns energy spent per node (array, length n_total; BS entry ignored).
    """
    E = np.zeros(n_total)
    for f, path in zip(flows, paths):
        bits = f["pkts"] * (f["bytes"] + cfg.HEADER_BYTES) * 8.0
        for a, b in zip(path[:-1], path[1:]):
            E[a] += tx_energy(bits, D[a, b], cfg)
            E[b] += rx_energy(bits, cfg)
        if path[-1] in aggregators:
            E[path[-1]] += cfg.E_DA * bits
    cbits = (cfg.CTRL_PKT_BYTES + cfg.HEADER_BYTES) * 8.0
    for node, (ntx, deg) in ctrl.items():
        E[node] += ntx * tx_energy(cbits, cfg.COMM_RANGE, cfg)
        E[node] += ntx * deg * rx_energy(cbits, cfg) * 0.5   # neighbours' broadcasts heard
    return E

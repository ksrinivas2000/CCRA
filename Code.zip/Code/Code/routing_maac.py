"""
Section 4.4 - Routing with a multi-agent actor-critic network trained by the optimiser.

Agents: every CH (target = SCH) and the SCH (target = BS).  Agents share one
actor (parameter sharing) so the optimiser searches a single weight vector.

Actor  : MLP(features of a candidate next hop) -> score; softmax over in-range
         neighbours (greedy when deployed).  Weights found by the optimiser
         (CCRA in the proposed method) maximising the episode return.
Critic : MLP(state) -> V(s), trained with TD(0) from a replay buffer
         (lr, batch size and epochs from Table 1); used to bootstrap the return
         of episodes cut off at the hop limit.
Reward : -w_dist * hop distance - w_delay * hop delay + w_trust * trust of next hop
         (+1 on reaching the target, -1 on a dead end).
Routes to the same target are merged into a tree so next hops are consistent.
"""
import numpy as np

N_FEAT = 8
N_STATE = 5


def relu(x):
    return np.maximum(x, 0.0)


class RoutingContext(object):
    """Snapshot of the network used by the agents for one round."""

    def __init__(self, D, LET, alive_mask, energy_norm, is_ch, trust, R, cfg, bs):
        self.D = D
        self.LET = LET
        self.alive = alive_mask
        self.e = energy_norm
        self.is_ch = is_ch
        self.trust = trust
        self.R = R
        self.cfg = cfg
        self.bs = bs
        self.maxd = max(D.max(), 1e-9)
        n = D.shape[0]
        A = (D <= R) & ~np.eye(n, dtype=bool)
        A &= alive_mask[None, :] & alive_mask[:, None]
        self.adj = [np.where(A[i])[0] for i in range(n)]
        self.degree = A.sum(1)
        bits = (cfg.CH_PKT_BYTES + cfg.HEADER_BYTES) * 8.0
        self.t_tx = bits / cfg.DATA_RATE_BPS

    def hop_delay(self, i, j):
        return self.t_tx * (1.0 + 0.5 * self.degree[j]) + self.D[i, j] / self.cfg.PROP_SPEED

    def reward(self, i, j):
        c = self.cfg
        d = self.D[i, j] / self.R
        dl = self.hop_delay(i, j) / (self.t_tx * 10.0)
        return -c.REWARD_W_DIST * d - c.REWARD_W_DELAY * dl + c.REWARD_W_TRUST * self.trust[j]

    def features(self, i, nbrs, tgt, load):
        d_it = self.D[i, tgt]
        f = np.empty((len(nbrs), N_FEAT))
        f[:, 0] = (d_it - self.D[nbrs, tgt]) / self.R          # progress toward target
        f[:, 1] = self.D[i, nbrs] / self.R                     # hop length
        f[:, 2] = self.e[nbrs]                                 # residual energy
        f[:, 3] = self.LET[i, nbrs] / self.cfg.LET_CAP         # link lifetime
        f[:, 4] = self.is_ch[nbrs]                             # CH / gateway role
        f[:, 5] = np.minimum(load[nbrs] / 5.0, 1.0)            # relay load this round
        f[:, 6] = self.trust[nbrs]                             # trust
        f[:, 7] = (nbrs == tgt)                                # is target
        return f

    def state(self, i, tgt, hops):
        return np.array([self.D[i, tgt] / self.maxd, hops / float(self.cfg.ROUTE_MAX_HOPS),
                         self.e[i], self.trust[i], 1.0])


class MLP(object):
    def __init__(self, n_in, hidden, rng):
        self.n_in, self.h = n_in, hidden
        self.size = n_in * hidden + hidden + hidden + 1
        self.theta = rng.normal(0, 0.3, self.size)

    def unpack(self, th):
        n, h = self.n_in, self.h
        W1 = th[:n * h].reshape(n, h)
        b1 = th[n * h:n * h + h]
        W2 = th[n * h + h:n * h + 2 * h]
        b2 = th[-1]
        return W1, b1, W2, b2

    def forward(self, X, th=None):
        W1, b1, W2, b2 = self.unpack(self.theta if th is None else th)
        return relu(X @ W1 + b1) @ W2 + b2


class Critic(MLP):
    def train(self, buf, cfg, rng):
        if len(buf) < cfg.ROUTE_BATCH:
            return
        S = np.array([b[0] for b in buf])
        Rw = np.array([b[1] for b in buf])
        S2 = np.array([b[2] for b in buf])
        done = np.array([b[3] for b in buf], float)
        lr, g = cfg.ROUTE_LR, cfg.ROUTE_GAMMA
        for _ in range(cfg.ROUTE_EPOCHS):
            target_theta = self.theta.copy()                       # target network
            y_all = Rw + g * (1 - done) * self.forward(S2, target_theta)
            perm = rng.permutation(len(S))
            for s in range(0, len(S), cfg.ROUTE_BATCH):
                bi = perm[s:s + cfg.ROUTE_BATCH]
                X, y = S[bi], y_all[bi]
                W1, b1, W2, b2 = self.unpack(self.theta)
                z = X @ W1 + b1
                h = relu(z)
                err = (h @ W2 + b2) - y                            # dL/dv for 0.5*MSE
                gW2 = h.T @ err / len(bi)
                gb2 = err.mean()
                dh = np.outer(err, W2) * (z > 0)
                gW1 = X.T @ dh / len(bi)
                gb1 = dh.mean(0)
                grad = np.concatenate([gW1.ravel(), gb1, gW2, [gb2]])
                self.theta -= lr * np.clip(grad, -5, 5)


class MAACRouter(object):
    def __init__(self, cfg, rng):
        self.cfg = cfg
        self.rng = rng
        self.actor = MLP(N_FEAT, cfg.ROUTE_HIDDEN, rng)
        self.critic = Critic(N_STATE, cfg.ROUTE_HIDDEN, rng)
        self.buffer = []
        self.trained = False
        self.last_curve = np.array([])

    # ----- one episode for one agent -----
    def rollout(self, ctx, src, tgt, theta=None, greedy=True, tree=None, load=None, record=None):
        cfg = self.cfg
        load = np.zeros(ctx.D.shape[0]) if load is None else load
        path, visited, ret, disc = [src], {src}, 0.0, 1.0
        cur = src
        for h in range(cfg.ROUTE_MAX_HOPS):
            if cur == tgt:
                break
            if tree is not None and (cur, tgt) in tree:
                nxt = tree[(cur, tgt)]
            else:
                nbrs = np.array([j for j in ctx.adj[cur] if j not in visited], int)
                if len(nbrs) == 0:
                    ret += disc * -1.0
                    if record is not None:
                        record.append((ctx.state(cur, tgt, h), -1.0, ctx.state(cur, tgt, h), True))
                    return path, ret, False
                sc = self.actor.forward(ctx.features(cur, nbrs, tgt, load), theta)
                if greedy:
                    nxt = int(nbrs[np.argmax(sc)])
                else:
                    p = np.exp(sc - sc.max())
                    p /= p.sum()
                    nxt = int(nbrs[self.rng.choice(len(nbrs), p=p)])
            if nxt in visited and nxt != tgt:
                ret += disc * -1.0
                return path, ret, False
            r = ctx.reward(cur, nxt) + (1.0 if nxt == tgt else 0.0)
            if record is not None:
                record.append((ctx.state(cur, tgt, h), r, ctx.state(nxt, tgt, h + 1), nxt == tgt))
            ret += disc * r
            disc *= cfg.ROUTE_GAMMA
            visited.add(nxt)
            path.append(nxt)
            cur = nxt
        if cur == tgt:
            return path, ret, True
        if self.trained:                                          # bootstrap with critic
            ret += disc * float(self.critic.forward(ctx.state(cur, tgt, cfg.ROUTE_MAX_HOPS)[None])[0])
        return path, ret, False

    # ----- training: critic (TD) + actor (optimiser) -----
    def train(self, optimizer, ctx, agents):
        """agents: list of (source, target)."""
        cfg = self.cfg
        rec = []
        for s, t in agents:                                       # experience with current actor
            for _ in range(3):
                self.rollout(ctx, s, t, greedy=False, record=rec)
        self.buffer = (self.buffer + rec)[-5000:]
        self.critic.train(self.buffer, cfg, self.rng)
        self.trained = True

        def fitness(theta):
            return -np.mean([self.rollout(ctx, s, t, theta=theta)[1] for s, t in agents])

        best, best_f, curve = optimizer(fitness, self.actor.size, -1.0, 1.0, cfg.ROUTE_POP,
                                        cfg.ROUTE_ITER, rng=self.rng, alpha=cfg.ALPHA,
                                        const=cfg.CONST, beta=cfg.BETA)
        if best_f <= fitness(self.actor.theta):
            self.actor.theta = best
        self.last_curve = curve
        return -best_f

    # ----- deployment: build merged routing trees -----
    def build_routes(self, ctx, agents, routes):
        """Adds next hops to `routes` {(node, dest): next_hop}; returns {src: (path, reached)}."""
        load = np.zeros(ctx.D.shape[0])
        out = {}
        for s, t in agents:
            path, _, ok = self.rollout(ctx, s, t, tree=routes, load=load)
            if not ok:
                path = bfs_path(ctx.adj, s, t)
                ok = path is not None
                path = path or [s, t]
            for a, b in zip(path[:-1], path[1:]):
                routes.setdefault((a, t), b)
                load[b] += 1
            out[s] = (path, ok)
        return out


def bfs_path(adj, src, dst):
    if src == dst:
        return [src]
    prev = {src: None}
    q = [src]
    while q:
        nq = []
        for u in q:
            for v in adj[u]:
                v = int(v)
                if v not in prev:
                    prev[v] = u
                    if v == dst:
                        p = [v]
                        while prev[p[-1]] is not None:
                            p.append(prev[p[-1]])
                        return p[::-1]
                    nq.append(v)
        q = nq
    return None


def bfs_tree_to(adj, dst):
    """Parent pointers toward dst (next hop from every reachable node)."""
    nxt = {dst: None}
    q = [dst]
    while q:
        nq = []
        for u in q:
            for v in adj[u]:
                v = int(v)
                if v not in nxt:
                    nxt[v] = u
                    nq.append(v)
        q = nq
    return nxt

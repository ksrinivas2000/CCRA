"""Distance and link-expiration-time (LET) matrices."""
import numpy as np


def distance_matrix(pos):
    d = pos[:, None, :] - pos[None, :, :]
    return np.sqrt((d ** 2).sum(-1))


def let_matrix(pos, vel, R, cap):
    """Time until each pair moves out of range R (3D, constant velocity). 0 if already out."""
    dp = pos[:, None, :] - pos[None, :, :]
    dv = vel[:, None, :] - vel[None, :, :]
    a = (dv ** 2).sum(-1)
    b = 2.0 * (dp * dv).sum(-1)
    c = (dp ** 2).sum(-1) - R * R
    disc = np.maximum(b * b - 4 * a * c, 0.0)
    with np.errstate(divide="ignore", invalid="ignore"):
        t = (-b + np.sqrt(disc)) / (2 * a)
    t = np.where(a < 1e-9, cap, t)
    t = np.where(c > 0, 0.0, t)
    t = np.clip(np.nan_to_num(t, nan=cap, posinf=cap), 0.0, cap)
    np.fill_diagonal(t, cap)
    return t

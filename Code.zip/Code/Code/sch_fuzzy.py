"""
Section 4.3 - Super Cluster Head selection with a Mamdani fuzzy inference system.

Input linguistic variable "node suitability parameter" P (one per criterion,
normalised so that LOW = good):
   admissible  - Z-curve      (Eq. 45)
   threshold   - triangular   (Eq. 46)
   excessive   - S-curve      (Eq. 47)
Criteria: distance CH->BS, energy deficit (1 - residual), intra-cluster cost (ICC),
          connectivity deficit (1 - normalised degree).
Output "SCH suitability index": unsuitable (Eq. 50), moderately suitable (Eq. 49),
suitable (Eq. 48); min-max inference, centroid defuzzification.
Crisp output is binned into low / medium / high / very high; the CH(s) with the
highest index are selected as SCH.
"""
import numpy as np

U = np.linspace(0.0, 1.0, 201)


def z_mf(x, a, b):
    return np.clip((b - x) / (b - a), 0.0, 1.0)


def s_mf(x, a, b):
    return np.clip((x - a) / (b - a), 0.0, 1.0)


def tri_mf(x, a, b, c):
    return np.maximum(np.minimum((x - a) / (b - a), (c - x) / (c - b)), 0.0)


def fuzzify(p, kappa1=0.4, p_xi=0.6):
    """Eq. 45-47 on |P| in [0, 1]."""
    return {
        "adm": z_mf(p, kappa1 * p_xi, p_xi),
        "thr": tri_mf(p, 0.3, 0.55, 0.8),
        "exc": s_mf(p, 0.6, 0.9),
    }


OUT = {
    "unsuitable": z_mf(U, 0.15, 0.40),            # Eq. 50
    "moderate": tri_mf(U, 0.30, 0.50, 0.70),      # Eq. 49
    "suitable": s_mf(U, 0.60, 0.85),              # Eq. 48
}

# (antecedents, consequent); antecedent = list of (criterion, term); AND = min
RULES = [
    ([("dist", "adm"), ("energy", "adm")], "suitable"),
    ([("dist", "adm"), ("icc", "adm"), ("conn", "adm")], "suitable"),
    ([("dist", "adm"), ("energy", "thr")], "moderate"),
    ([("dist", "thr"), ("energy", "adm")], "moderate"),
    ([("dist", "thr"), ("energy", "thr")], "moderate"),
    ([("icc", "thr"), ("energy", "adm")], "moderate"),
    ([("dist", "exc")], "unsuitable"),
    ([("energy", "exc")], "unsuitable"),
    ([("icc", "exc"), ("conn", "exc")], "unsuitable"),
]


def infer(params):
    """params: dict criterion -> value in [0,1]. Returns crisp suitability in [0,1]."""
    mu = {c: fuzzify(v) for c, v in params.items()}
    agg = np.zeros_like(U)
    for ants, cons in RULES:
        strength = min(float(mu[c][t]) for c, t in ants)
        agg = np.maximum(agg, np.minimum(strength, OUT[cons]))
    if agg.sum() < 1e-12:
        return 0.0
    return float((agg * U).sum() / agg.sum())


def category(s):
    if s < 0.35:
        return "low"
    if s < 0.55:
        return "medium"
    if s < 0.75:
        return "high"
    return "very high"


def select_sch(chs, ch_of, D, energy_norm, bs, R, degree_of, n_sch=1):
    chs = list(chs)
    dmax = max(D[chs, bs].max(), 1e-9)
    degmax = max(max(degree_of.get(c, 0) for c in chs), 1)
    scores = {}
    for c in chs:
        members = [m for m, h in ch_of.items() if h == c and m != c]
        icc = np.mean(D[members, c] ** 2) / R ** 2 if members else 0.0
        params = {
            "dist": D[c, bs] / dmax,
            "energy": 1.0 - energy_norm[c],
            "icc": float(np.clip(icc, 0, 1)),
            "conn": 1.0 - degree_of.get(c, 0) / float(degmax),
        }
        scores[c] = infer(params)
    ranked = sorted(chs, key=lambda c: (-scores[c], D[c, bs]))
    return ranked[:n_sch], scores

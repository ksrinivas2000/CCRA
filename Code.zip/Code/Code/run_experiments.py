#!/usr/bin/env python3
"""
Run the whole experiment grid: number of nodes x optimisation method (x seeds),
each simulated up to the largest number of rounds, then summarise the metrics
at every requested round count.

Example (inside the ns-3.31 directory):
  python3 scratch/ccra_fanet/run_experiments.py --ns3-dir . \
      --nodes 50 100 150 200 --rounds 100 200 300 400 500 \
      --methods PSO GWO CCO DRA CCRA --jobs 4

Outputs (in --out):
  raw/rounds_<method>_N<n>_seed<s>_<engine>.csv   per-round metrics
  summary_vs_rounds.csv                            metrics at each round count
  summary_vs_nodes.csv                             metrics at the final round count
  plots/                                           figures (via plot_results.py)
"""
import argparse
import glob
import os
import subprocess
import sys
from concurrent.futures import ThreadPoolExecutor

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)


def ns3_env(ns3_dir):
    env = dict(os.environ)
    ns3_dir = os.path.abspath(ns3_dir)
    py = os.path.join(ns3_dir, "build", "bindings", "python")
    lib = os.path.join(ns3_dir, "build", "lib")
    env["PYTHONPATH"] = py + os.pathsep + env.get("PYTHONPATH", "")
    env["LD_LIBRARY_PATH"] = lib + os.pathsep + env.get("LD_LIBRARY_PATH", "")
    return env


def run_one(job):
    n, method, seed, rounds, engine, out, env, extra = job
    cmd = [sys.executable, os.path.join(HERE, "fanet_sim.py"), "--nodes", str(n),
           "--rounds", str(rounds), "--method", method, "--engine", engine,
           "--seed", str(seed), "--out", out, "--quiet"] + extra
    log = os.path.join(out, "log_%s_N%d_seed%d.txt" % (method, n, seed))
    print("start ", " ".join(cmd[1:]))
    sys.stdout.flush()
    with open(log, "w") as fh:
        rc = subprocess.call(cmd, stdout=fh, stderr=subprocess.STDOUT, env=env)
    print("done  %s N=%d seed=%d -> exit %d (log: %s)" % (method, n, seed, rc, log))
    sys.stdout.flush()
    return rc


def summarise(raw_dir, rounds_list, out_dir):
    import pandas as pd
    import numpy as np

    files = glob.glob(os.path.join(raw_dir, "rounds_*.csv"))
    if not files:
        print("no result files found in", raw_dir)
        return
    df = pd.concat([pd.read_csv(f) for f in files], ignore_index=True)
    rows = []
    for (eng, method, n, seed), g in df.groupby(["engine", "method", "nodes", "seed"]):
        g = g.sort_values("round")
        for R in rounds_list:
            h = g[g["round"] <= R]
            if h.empty:
                continue
            last = h.iloc[-1]
            rows.append({
                "engine": eng, "method": method, "nodes": n, "seed": seed, "rounds": R,
                "rounds_completed": int(last["round"]),
                "energy_J": float(h["energy_round_J"].sum()),           # total consumed up to R
                "avg_residual_J": float(last["avg_residual_J"]),
                "alive": int(last["alive"]),
                "delay_ms": float(np.nanmean(h["delay_ms"])),
                "pdr": float(np.nanmean(h["pdr"])),
                "throughput_kbps": float(np.nanmean(h["throughput_kbps"])),
                "distance_m": float(h["distance_m"].mean()),
                "node_degree": float(h["node_degree"].mean()),
                "link_lifetime_s": float(h["link_lifetime_s"].mean()),
                "icc": float(h["icc"].mean()),
                "lbf": float(h["lbf"].mean()),
                "fitness": float(h["fitness"].mean()),
            })
    s = pd.DataFrame(rows)
    keys = ["engine", "method", "nodes", "rounds"]
    mean = s.groupby(keys).mean(numeric_only=True).reset_index().drop(columns=["seed"])
    std = s.groupby(keys).std(numeric_only=True).reset_index().drop(columns=["seed"])
    mean.to_csv(os.path.join(out_dir, "summary_vs_rounds.csv"), index=False)
    if s["seed"].nunique() > 1:
        std.to_csv(os.path.join(out_dir, "summary_vs_rounds_std.csv"), index=False)
    final = mean[mean["rounds"] == max(rounds_list)]
    final.to_csv(os.path.join(out_dir, "summary_vs_nodes.csv"), index=False)
    print("wrote", os.path.join(out_dir, "summary_vs_rounds.csv"))
    print("wrote", os.path.join(out_dir, "summary_vs_nodes.csv"))


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--nodes", type=int, nargs="+", default=[50, 100, 150, 200])
    ap.add_argument("--rounds", type=int, nargs="+", default=[100, 200, 300, 400, 500])
    ap.add_argument("--methods", nargs="+", default=["PSO", "GWO", "CCO", "DRA", "CCRA"])
    ap.add_argument("--seeds", type=int, nargs="+", default=[1])
    ap.add_argument("--engine", default="ns3", choices=["ns3", "python"])
    ap.add_argument("--ns3-dir", default=".", help="ns-3.31 root (contains build/)")
    ap.add_argument("--out", default="results")
    ap.add_argument("--jobs", type=int, default=1, help="parallel simulations")
    ap.add_argument("--pop", type=int)
    ap.add_argument("--iters", type=int)
    ap.add_argument("--summarise-only", action="store_true")
    a = ap.parse_args()

    raw = os.path.join(a.out, "raw")
    os.makedirs(raw, exist_ok=True)
    rounds_max = max(a.rounds)
    if not a.summarise_only:
        env = ns3_env(a.ns3_dir) if a.engine == "ns3" else dict(os.environ)
        extra = []
        if a.pop:
            extra += ["--pop", str(a.pop)]
        if a.iters:
            extra += ["--iters", str(a.iters)]
        jobs = [(n, m, s, rounds_max, a.engine, raw, env, extra)
                for n in a.nodes for m in a.methods for s in a.seeds]
        with ThreadPoolExecutor(max_workers=a.jobs) as ex:
            codes = list(ex.map(run_one, jobs))
        if any(codes):
            print("WARNING: %d run(s) failed - check the log files in %s" % (sum(1 for c in codes if c), raw))

    summarise(raw, sorted(a.rounds), a.out)
    subprocess.call([sys.executable, os.path.join(HERE, "plot_results.py"), "--results", a.out])


if __name__ == "__main__":
    main()

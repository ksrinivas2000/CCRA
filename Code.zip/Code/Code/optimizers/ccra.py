"""
Cuckoo Catfish Religions Algorithm (CCRA) - proposed method.

CCRA = CCO (cco.py) with the compressed-space update replaced by the hybrid
CCO + DRA update of the manuscript:

    Eq. (27)  DRA miracle term:   C_new = C_x * cos(pi/2) * [R - cos(R)],  R <= mp, R <= 0.5
    Eq. (32)  CCRA update:        C_new = a / (a - 1) * Delta
              a     = cos(pi/2) * [R - cos(R)]
              Delta = O1*aleph*((C_best + C_psi1)/2 - C_psi2) + psi3/2*(C_psi3 - C_psi4)

NOTE: cos(pi/2) = 0, so with config.CCRA_LITERAL_EQ32 = True the Eq. (32) step
gives a ~= 0 and C_new ~= 0 (the individual jumps to the lower bound; the
greedy rule of Eq. (44) then usually rejects it).  Set CCRA_LITERAL_EQ32 = False
to use cos(pi/2 * R) instead, which keeps the DRA term non-zero and adds C_x
back so the update is a move from the current position.  See README.
"""
import math
import numpy as np

from .cco import CuckooCatfish

try:
    import config as _cfg
    _LITERAL = bool(getattr(_cfg, "CCRA_LITERAL_EQ32", True))
except Exception:  # pragma: no cover
    _LITERAL = True


class CCRA(CuckooCatfish):
    name = "CCRA"

    def __init__(self, *a, **kw):
        self.literal = kw.pop("literal_eq32", _LITERAL)
        super(CCRA, self).__init__(*a, **kw)

    def compressed_update(self, X, i, best):
        delta, _ = self.coop_term(X, i, best)
        R = self.rng.random()
        if R <= self.mp and R <= 0.5:
            if self.literal:
                a = math.cos(math.pi / 2) * (R - math.cos(R))            # Eq. (27)/(32) as written
                return a / (a - 1.0) * delta                              # Eq. (32)
            a = math.cos(math.pi / 2 * R) * (R - math.cos(R))
            return X[i] + a / (a - 1.0) * delta
        return X[i] + delta                                               # Eq. (26)


def optimize(fitness, dim, lb=0.0, ub=1.0, pop_size=30, max_iter=100, rng=None, **kw):
    rng = rng if rng is not None else np.random.default_rng()
    return CCRA(fitness, dim, lb, ub, pop_size, max_iter, rng, **kw).run()

"""
Divine Religions Algorithm (DRA) [Mozhdehi et al., Cluster Computing 28:253, 2025].

Re-implemented from the published description of its operators:
  * population split into belief groups, each led by a missionary (group best)
  * miracle operator (exploration, probability mp):
        x_new = x * cos(pi/2) * (r - cos r)          if r <= 0.5
        x_new = x + r * (x - round(1**r) * x)         otherwise
  * proselytism operator (exploitation toward the leader and group mean)
  * reward / penalty operator (small multiplicative perturbation)
  * replacement operator (worst follower re-spawned)
Check against the authors' reference code if exact replication matters.
"""
import math
import numpy as np


def optimize(fitness, dim, lb=0.0, ub=1.0, pop_size=30, max_iter=100, rng=None,
             beta=0.5, n_groups=3, **kw):
    rng = rng if rng is not None else np.random.default_rng()
    lb = np.full(dim, lb, float) if np.isscalar(lb) else np.asarray(lb, float)
    ub = np.full(dim, ub, float) if np.isscalar(ub) else np.asarray(ub, float)
    mp = beta

    X = lb + rng.random((pop_size, dim)) * (ub - lb)
    F = np.array([fitness(x) for x in X])
    groups = np.arange(pop_size) % n_groups
    curve = []

    for t in range(max_iter):
        G = 1.0 - t / float(max_iter)
        b = int(np.argmin(F))
        leader = X[b].copy()
        for i in range(pop_size):
            members = np.where(groups == groups[i])[0]
            missionary = X[members[np.argmin(F[members])]]
            r = rng.random()
            if r <= mp:                                          # miracle operator
                r2 = rng.random()
                if r2 <= 0.5:
                    xn = X[i] * math.cos(math.pi / 2) * (r2 - math.cos(r2))
                else:
                    xn = X[i] + r2 * (X[i] - round(1 ** r2) * X[i])
                xn = xn + G * (rng.random(dim) - 0.5) * (ub - lb)
            else:                                                # proselytism operator
                mean_g = X[members].mean(0)
                xn = X[i] + rng.random(dim) * (missionary - X[i]) \
                    + rng.random(dim) * (leader - mean_g) * (1 - G)
            if rng.random() < 0.5:                               # reward / penalty
                xn = xn * (1 + (0.01 if rng.random() < 0.5 else -0.01) * rng.normal(0, 1, dim))
            xn = np.clip(xn, lb, ub)
            fn = fitness(xn)
            if fn < F[i]:
                X[i], F[i] = xn, fn
        w = int(np.argmax(F))                                    # replacement operator
        if rng.random() < 0.3:
            X[w] = lb + rng.random(dim) * (ub - lb)
            F[w] = fitness(X[w])
            groups[w] = rng.integers(n_groups)
        curve.append(F.min())
    b = int(np.argmin(F))
    return X[b].copy(), F[b], np.array(curve)

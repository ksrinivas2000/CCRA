"""
Optimiser registry.

Every optimiser exposes the same function:

    optimize(fitness, dim, lb, ub, pop_size, max_iter, rng=None, **kw)
        -> (best_x, best_f, curve)

`fitness` maps a 1-D numpy vector to a float that is MINIMISED.
`curve` is the best fitness after each iteration.
"""
from . import pso, gwo, cco, dra, ccra

REGISTRY = {
    "PSO": pso.optimize,
    "GWO": gwo.optimize,
    "CCO": cco.optimize,
    "DRA": dra.optimize,
    "CCRA": ccra.optimize,
}


def get_optimizer(name):
    key = name.upper()
    if key not in REGISTRY:
        raise ValueError("Unknown optimiser %r. Available: %s" % (name, ", ".join(REGISTRY)))
    return REGISTRY[key]

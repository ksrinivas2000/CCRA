"""Grey Wolf Optimiser (baseline)."""
import numpy as np


def optimize(fitness, dim, lb=0.0, ub=1.0, pop_size=30, max_iter=100, rng=None, **kw):
    rng = rng if rng is not None else np.random.default_rng()
    lb = np.full(dim, lb, float) if np.isscalar(lb) else np.asarray(lb, float)
    ub = np.full(dim, ub, float) if np.isscalar(ub) else np.asarray(ub, float)

    X = lb + rng.random((pop_size, dim)) * (ub - lb)
    F = np.array([fitness(x) for x in X])
    order = np.argsort(F)
    leaders = [X[order[i]].copy() for i in range(3)]
    lf = [F[order[i]] for i in range(3)]
    curve = []

    for t in range(max_iter):
        a = 2.0 - 2.0 * t / max(1, max_iter - 1)
        newX = np.zeros_like(X)
        for L in leaders:
            A = 2 * a * rng.random((pop_size, dim)) - a
            C = 2 * rng.random((pop_size, dim))
            D = np.abs(C * L - X)
            newX += L - A * D
        X = np.clip(newX / 3.0, lb, ub)
        F = np.array([fitness(x) for x in X])
        pool_x = np.vstack([X] + leaders)
        pool_f = np.concatenate([F, lf])
        order = np.argsort(pool_f)
        leaders = [pool_x[order[i]].copy() for i in range(3)]
        lf = [pool_f[order[i]] for i in range(3)]
        curve.append(lf[0])
    return leaders[0], lf[0], np.array(curve)

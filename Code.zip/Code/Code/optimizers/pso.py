"""Particle Swarm Optimisation (baseline)."""
import numpy as np


def optimize(fitness, dim, lb=0.0, ub=1.0, pop_size=30, max_iter=100, rng=None,
             w_max=0.9, w_min=0.4, c1=1.5, c2=1.5, **kw):
    rng = rng if rng is not None else np.random.default_rng()
    lb = np.full(dim, lb, float) if np.isscalar(lb) else np.asarray(lb, float)
    ub = np.full(dim, ub, float) if np.isscalar(ub) else np.asarray(ub, float)
    vmax = 0.2 * (ub - lb)

    X = lb + rng.random((pop_size, dim)) * (ub - lb)
    V = np.zeros_like(X)
    F = np.array([fitness(x) for x in X])
    P, PF = X.copy(), F.copy()
    g = int(np.argmin(PF))
    best_x, best_f = P[g].copy(), PF[g]
    curve = []

    for t in range(max_iter):
        w = w_max - (w_max - w_min) * t / max(1, max_iter - 1)
        r1, r2 = rng.random((pop_size, dim)), rng.random((pop_size, dim))
        V = w * V + c1 * r1 * (P - X) + c2 * r2 * (best_x - X)
        V = np.clip(V, -vmax, vmax)
        X = np.clip(X + V, lb, ub)
        F = np.array([fitness(x) for x in X])
        better = F < PF
        P[better], PF[better] = X[better], F[better]
        g = int(np.argmin(PF))
        if PF[g] < best_f:
            best_x, best_f = P[g].copy(), PF[g]
        curve.append(best_f)
    return best_x, best_f, np.array(curve)

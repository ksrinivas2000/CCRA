"""
Cuckoo Catfish Optimizer (CCO) [Wang et al., Artif. Intell. Rev. 58:326, 2025],
implemented from the update rules written in the manuscript (Eqs. 25-44):

  compressed-space strategy ...... Eq. (25)/(26), refinement Eq. (33)/(34)
  surround search (spiral) ....... Eq. (35)
  spherical wrap-around .......... Eq. (36)-(37)
  adjustment mechanism ........... Eq. (38)-(39)
  transition strategy ............ Eq. (40)
  chaotic predation .............. Eq. (41)-(42)
  death & parasitic .............. Eq. (43)
  greedy update / counter q ...... Eq. (44)

Symbols the manuscript does not define numerically are given simple,
documented choices below (helix coefficients g/h, shrink factor T^m, chaotic
coefficient Z via a logistic map, Levy steps for I and lev(B)).
Check them against the CCO authors' reference code if exact replication matters.

CCRA (ccra.py) subclasses this and replaces the compressed-space update with
the hybrid CCO+DRA update of Eq. (32).
"""
import math
import numpy as np


def levy(rng, size, beta=1.5):
    sigma = (math.gamma(1 + beta) * math.sin(math.pi * beta / 2) /
             (math.gamma((1 + beta) / 2) * beta * 2 ** ((beta - 1) / 2))) ** (1 / beta)
    u = rng.normal(0, sigma, size)
    v = rng.normal(0, 1, size)
    return u / np.abs(v) ** (1 / beta)


class CuckooCatfish(object):
    name = "CCO"

    def __init__(self, fitness, dim, lb, ub, pop_size, max_iter, rng,
                 alpha=0.1, const=0.3, beta=0.5, quantize=None, **kw):
        self.f = fitness
        self.dim = dim
        self.lb = np.full(dim, lb, float) if np.isscalar(lb) else np.asarray(lb, float)
        self.ub = np.full(dim, ub, float) if np.isscalar(ub) else np.asarray(ub, float)
        self.N = pop_size
        self.T = max_iter
        self.rng = rng
        self.alpha = alpha        # Levy / predation step scale  (Table 1 "alpha")
        self.const = const        # adjustment-mechanism probability (Table 1 "Constant")
        self.mp = beta            # DRA miracle probability, used by CCRA (Table 1 "beta")
        self.quantize = quantize  # grid for Round() in Eq. (38); None = plain rounding off
        self.span = self.ub - self.lb
        self.z = 0.7              # logistic-map state for chaotic coefficient Z

    # ---------- helpers ----------
    def clip(self, x):
        return np.clip(x, self.lb, self.ub)

    def round_fn(self, x):
        if self.quantize:
            return np.round(x / self.quantize) * self.quantize
        return x

    def aggregation(self, X):
        """D_x: normalised distance of each individual from the population mean."""
        d = np.linalg.norm(X - X.mean(0), axis=1)
        return d / (np.linalg.norm(self.span) + 1e-12)

    def chaos(self):
        self.z = 4.0 * self.z * (1.0 - self.z)
        if self.z <= 0 or self.z >= 1:
            self.z = self.rng.random()
        return self.z

    # ---------- compressed space: Eq. (25)/(26) ----------
    def coop_term(self, X, i, best):
        r = self.rng.choice(self.N, 4, replace=False)
        o1, psi3 = self.rng.random(), self.rng.random()
        aleph = 2.0 * self.G * (2 * self.rng.random() - 1)       # cooperation intensity
        delta = o1 * aleph * ((best + X[r[0]]) / 2.0 - X[r[1]]) + psi3 / 2.0 * (X[r[2]] - X[r[3]])
        return delta, aleph

    def compressed_update(self, X, i, best):
        delta, _ = self.coop_term(X, i, best)
        return X[i] + delta                                      # Eq. (26)

    def refine_update(self, X, i, best):
        r = self.rng.choice(self.N, 3, replace=False)
        aleph = abs(2.0 * self.G * (2 * self.rng.random() - 1))
        if self.rng.random() < 0.5:                              # Eq. (33)
            o2 = self.rng.random()
            return o2 * (X[r[0]] + aleph * (X[r[0]] - X[r[1]])) + (1 - o2) * X[i]
        return X[r[0]] + aleph * (best - X[i] + X[r[1]] - X[r[2]])  # Eq. (34)

    # ---------- surround search: Eq. (35), (36) ----------
    def spiral_update(self, X, i, best, it, Dx):
        H = self.rng.choice([-1.0, 1.0])
        Q1 = self.rng.random()
        step = best - X[i]                                       # attraction vector
        l = self.rng.uniform(-1, 1)
        Tm = 2.0 * self.G * self.rng.random()                    # shrink factor T^m
        helix = math.exp(l) * (math.cos(2 * math.pi * l) if i % 2 == 0 else math.sin(2 * math.pi * l))
        E = self.alpha * self.rng.normal(0, 1, self.dim)         # predation mechanism
        return X[i] + H * Q1 * step / 2.0 + Tm * helix * (1 - Q1) * np.abs(step) + E * Dx / it

    def spherical_update(self, X, i, top3, it):
        rot = top3 + [X.mean(0)]
        ref = rot[self.rng.integers(len(rot))]
        H = self.rng.choice([-1.0, 1.0])
        w = 1.0 - (math.exp(it / self.T) - 1.0) / (math.e - 1.0)  # Eq. (37)
        W1 = self.rng.uniform(0, 2 * math.pi, self.dim)
        W2 = self.rng.uniform(0, 2 * math.pi, self.dim)
        co = self.rng.integers(1, 4)
        if co == 1:
            return ref + 2 * w * H * np.cos(W1) * np.sin(W2) * (ref - X[i])
        if co == 2:
            return ref + 2 * w * H * np.sin(W1) * np.cos(W2) * (ref - X[i])
        return ref + 2 * w * H * np.cos(W2) * (ref - X[i])

    def adjust_update(self, X, xnew, it):                        # Eq. (38)-(39)
        r = self.rng.choice(self.N, 2, replace=False)
        psi1, Q1 = self.rng.random(), self.rng.random()
        H = self.rng.choice([-1.0, 1.0])
        lesp = psi1 * X[r[0]] + (1 - psi1) * X[r[1]]
        return self.round_fn(lesp) + H * psi1 * Q1 / float(it) ** 4 * xnew

    def transition_update(self, X, i, best, it):                 # Eq. (40)
        step2 = best - X[i]
        if i % 2 == 0:
            psi1, psi3 = self.rng.random(), self.rng.random()
            return (self.G / it) * (psi1 * best - psi3 * X[i]) + \
                self.G ** 2 * self.alpha * levy(self.rng, self.dim) * np.abs(step2)
        j = self.rng.integers(self.N)
        H = self.rng.choice([-1.0, 1.0])
        De = self.G * H
        Q1, Q2, Q3 = self.rng.random(3)
        return (best + X[j]) / 2.0 + De * (2 * Q1 * step2 - Q2 / 2.0 * (De * Q3 - 1))

    # ---------- chaotic predation: Eq. (41)-(42) ----------
    def predation_update(self, X, i, best, Dx, D_in):
        H = self.rng.choice([-1.0, 1.0])
        B = self.rng.random()
        aleph = abs(2.0 * self.G * (2 * self.rng.random() - 1))
        WF = aleph * self.rng.random()                           # Eq. (42)
        T5 = self.G ** 5
        base = H * B * (best - X[i])
        if Dx > D_in:
            return best + base
        if Dx > D_in * WF:
            Z = self.chaos()
            return best * (1 - T5 * Z * self.G) + base
        I = self.alpha * levy(self.rng, self.dim)
        return best * (1 - T5 * I) + base

    # ---------- death & parasitic: Eq. (43) ----------
    def death_update(self, X):
        if self.rng.random() > self.G:
            low, up = X.min(0), X.max(0)                          # egg bounds
            return self.rng.random(self.dim) * (up - low) + low
        return self.rng.random(self.dim) * self.span + self.lb

    # ---------- main loop ----------
    def run(self):
        rng = self.rng
        X = self.lb + rng.random((self.N, self.dim)) * self.span   # Eq. (23)-(24)
        F = np.array([self.f(x) for x in X])                       # Eq. (22)
        q = np.zeros(self.N, int)
        D_in = self.aggregation(X).mean() + 1e-12
        curve = []
        for t in range(1, self.T + 1):
            self.G = 1.0 - t / float(self.T)
            order = np.argsort(F)
            best = X[order[0]].copy()
            top3 = [X[order[k]].copy() for k in range(min(3, self.N))]
            Dx_all = self.aggregation(X)
            for i in range(self.N):
                R = rng.random()
                if q[i] > 0.8 * self.N or (q[i] > 5 and R > self.G):
                    xn = self.death_update(X)                       # stagnant -> re-spawn
                elif R < self.G:                                    # exploration phase
                    if t <= self.T // 3:
                        xn = self.compressed_update(X, i, best)
                    else:
                        xn = self.refine_update(X, i, best)
                elif R < 0.5 + 0.5 * self.G:                        # surround search
                    if rng.random() < 0.5:
                        xn = self.spiral_update(X, i, best, t, Dx_all[i])
                    else:
                        xn = self.spherical_update(X, i, top3, t)
                    if rng.random() < self.const:
                        xn = self.adjust_update(X, xn, t)
                    if rng.random() < 0.5:
                        xn = self.transition_update(X, i, best, t)
                else:
                    xn = self.predation_update(X, i, best, Dx_all[i], D_in)
                # retain part of the old position when the search is "alert"
                if q[i] > 0.8 * self.N or R > self.G:
                    v = 0.2 * self.G + 0.2
                    keep = rng.random(self.dim) < v
                    xn = np.where(keep, X[i], xn)
                xn = self.clip(xn)
                fn = self.f(xn)
                if fn < F[i]:                                       # Eq. (44)
                    X[i], F[i], q[i] = xn, fn, 0
                else:
                    q[i] += 1
            curve.append(F.min())
        b = int(np.argmin(F))
        return X[b].copy(), F[b], np.array(curve)


def optimize(fitness, dim, lb=0.0, ub=1.0, pop_size=30, max_iter=100, rng=None, **kw):
    rng = rng if rng is not None else np.random.default_rng()
    return CuckooCatfish(fitness, dim, lb, ub, pop_size, max_iter, rng, **kw).run()

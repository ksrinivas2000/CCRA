"""
ns-3.31 engine (Python bindings).

  * N UAV nodes + 1 ground BS
  * 3D Gauss-Markov mobility inside a 500 x 500 x [ALT_MIN, ALT_MAX] box
  * 802.11b ad hoc, 1 Mbps (DsssRate1Mbps), RangePropagationLossModel = COMM_RANGE
  * Internet stack; per-round host routes (Ipv4StaticRouting) installed from the
    routing decisions (member->CH, CH->SCH via MAAC, SCH->BS via MAAC)
  * UdpServer on every node, UdpClient per flow per round
  * FlowMonitor for delivered packets, delay and throughput

The simulator is advanced one round at a time with Simulator.Stop() + Run(),
and the Python controller re-clusters between rounds.
"""
import ns.core
import ns.network
import ns.mobility
import ns.wifi
import ns.internet
import ns.applications
import ns.flow_monitor

import numpy as np

PORT = 9


class NS3Engine(object):
    name = "ns3"

    def __init__(self, n_uav, cfg, seed=1):
        self.cfg = cfg
        self.n = n_uav
        ns.core.RngSeedManager.SetSeed(int(seed))
        ns.core.RngSeedManager.SetRun(1)

        self.nodes = ns.network.NodeContainer()
        self.nodes.Create(n_uav + 1)                         # last node = BS

        # ---- WiFi ad hoc, 1 Mbps, hard range ----
        wifi = ns.wifi.WifiHelper()
        if hasattr(ns.wifi, "WIFI_STANDARD_80211b"):
            wifi.SetStandard(ns.wifi.WIFI_STANDARD_80211b)
        else:
            wifi.SetStandard(ns.wifi.WIFI_PHY_STANDARD_80211b)
        wifi.SetRemoteStationManager("ns3::ConstantRateWifiManager",
                                     "DataMode", ns.core.StringValue(cfg.WIFI_MODE),
                                     "ControlMode", ns.core.StringValue(cfg.WIFI_MODE))
        try:
            phy = ns.wifi.YansWifiPhyHelper.Default()       # ns-3.31
        except AttributeError:
            phy = ns.wifi.YansWifiPhyHelper()               # newer releases
        chan = ns.wifi.YansWifiChannelHelper()
        chan.SetPropagationDelay("ns3::ConstantSpeedPropagationDelayModel",
                                 "Speed", ns.core.DoubleValue(cfg.PROP_SPEED))
        chan.AddPropagationLoss("ns3::RangePropagationLossModel",
                                "MaxRange", ns.core.DoubleValue(cfg.COMM_RANGE))
        phy.SetChannel(chan.Create())
        mac = ns.wifi.WifiMacHelper()
        mac.SetType("ns3::AdhocWifiMac")
        self.devices = wifi.Install(phy, mac, self.nodes)

        # ---- mobility ----
        uavs = ns.network.NodeContainer()
        for i in range(n_uav):
            uavs.Add(self.nodes.Get(i))
        mob = ns.mobility.MobilityHelper()
        mob.SetPositionAllocator(
            "ns3::RandomBoxPositionAllocator",
            "X", ns.core.StringValue("ns3::UniformRandomVariable[Min=0|Max=%g]" % cfg.AREA_X),
            "Y", ns.core.StringValue("ns3::UniformRandomVariable[Min=0|Max=%g]" % cfg.AREA_Y),
            "Z", ns.core.StringValue("ns3::UniformRandomVariable[Min=%g|Max=%g]" % (cfg.ALT_MIN, cfg.ALT_MAX)))
        mob.SetMobilityModel(
            "ns3::GaussMarkovMobilityModel",
            "Bounds", ns.mobility.BoxValue(ns.mobility.Box(0, cfg.AREA_X, 0, cfg.AREA_Y,
                                                           cfg.ALT_MIN, cfg.ALT_MAX)),
            "TimeStep", ns.core.TimeValue(ns.core.Seconds(cfg.GM_TIMESTEP)),
            "Alpha", ns.core.DoubleValue(cfg.GM_ALPHA),
            "MeanVelocity", ns.core.StringValue(
                "ns3::UniformRandomVariable[Min=%g|Max=%g]" % (cfg.SPEED_MIN, cfg.SPEED_MAX)),
            "MeanDirection", ns.core.StringValue("ns3::UniformRandomVariable[Min=0|Max=6.283185307]"),
            "MeanPitch", ns.core.StringValue("ns3::UniformRandomVariable[Min=-0.05|Max=0.05]"))
        mob.Install(uavs)

        bs_mob = ns.mobility.MobilityHelper()
        alloc = ns.mobility.ListPositionAllocator()
        alloc.Add(ns.core.Vector(cfg.BS_POS[0], cfg.BS_POS[1], cfg.BS_POS[2]))
        bs_mob.SetPositionAllocator(alloc)
        bs_mob.SetMobilityModel("ns3::ConstantPositionMobilityModel")
        bs_mob.Install(self.nodes.Get(n_uav))

        # ---- internet ----
        stack = ns.internet.InternetStackHelper()
        stack.Install(self.nodes)
        addr = ns.internet.Ipv4AddressHelper()
        addr.SetBase(ns.network.Ipv4Address("10.1.0.0"), ns.network.Ipv4Mask("255.255.0.0"))
        self.ifaces = addr.Assign(self.devices)
        self.addr = [self.ifaces.GetAddress(i) for i in range(n_uav + 1)]
        self.addr_index = {str(a): i for i, a in enumerate(self.addr)}
        srh = ns.internet.Ipv4StaticRoutingHelper()
        self.static = []
        for i in range(n_uav + 1):
            ipv4 = self.nodes.Get(i).GetObject(ns.internet.Ipv4.GetTypeId())
            self.static.append(srh.GetStaticRouting(ipv4))

        # ---- servers + flow monitor ----
        server = ns.applications.UdpServerHelper(PORT)
        apps = server.Install(self.nodes)
        apps.Start(ns.core.Seconds(0.0))
        self.fm_helper = ns.flow_monitor.FlowMonitorHelper()
        self.monitor = self.fm_helper.InstallAll()
        self.prev = {}
        self.rng = np.random.default_rng(seed)
        self.mobility = [self.nodes.Get(i).GetObject(ns.mobility.MobilityModel.GetTypeId())
                         for i in range(n_uav + 1)]

    # ---------------------------------------------------------------
    def state(self):
        pos = np.zeros((self.n + 1, 3))
        vel = np.zeros((self.n + 1, 3))
        for i, m in enumerate(self.mobility):
            p, v = m.GetPosition(), m.GetVelocity()
            pos[i] = (p.x, p.y, p.z)
            vel[i] = (v.x, v.y, v.z)
        return pos, vel

    def _install_routes(self, routes):
        for sr in self.static:                               # drop last round's host routes
            for k in range(sr.GetNRoutes() - 1, -1, -1):
                if sr.GetRoute(k).IsHost():
                    sr.RemoveRoute(k)
        for (node, dest), nh in routes.items():
            self.static[node].AddHostRouteTo(self.addr[dest], self.addr[nh], 1)

    def run_round(self, routes, flows, duration):
        self._install_routes(routes)
        for f in flows:
            n_pkts = int(f["pkts"])
            client = ns.applications.UdpClientHelper(self.addr[f["dst"]], PORT)
            client.SetAttribute("MaxPackets", ns.core.UintegerValue(n_pkts))
            client.SetAttribute("Interval", ns.core.TimeValue(
                ns.core.Seconds(max(duration * 0.8 / max(n_pkts, 1), 0.001))))
            client.SetAttribute("PacketSize", ns.core.UintegerValue(int(max(f["bytes"], 12))))
            app = client.Install(self.nodes.Get(f["src"]))
            # Start/Stop are relative to now for applications installed mid-simulation
            app.Start(ns.core.Seconds(0.01 + 0.1 * self.rng.random()))
            app.Stop(ns.core.Seconds(duration * 0.95))

        ns.core.Simulator.Stop(ns.core.Seconds(duration))
        ns.core.Simulator.Run()
        return self._collect()

    def _collect(self):
        self.monitor.CheckForLostPackets()
        classifier = self.fm_helper.GetClassifier()
        per_pair = {}
        tot_tx = tot_rx = 0
        tot_delay = 0.0
        tot_bytes = 0
        for flow_id, st in self.monitor.GetFlowStats():
            tx, rx = st.txPackets, st.rxPackets
            dsum, rb = st.delaySum.GetSeconds(), st.rxBytes
            p = self.prev.get(flow_id, (0, 0, 0.0, 0))
            dtx, drx, dd, db = tx - p[0], rx - p[1], dsum - p[2], rb - p[3]
            self.prev[flow_id] = (tx, rx, dsum, rb)
            if dtx == 0 and drx == 0:
                continue
            t = classifier.FindFlow(flow_id)
            s = self.addr_index.get(str(t.sourceAddress))
            d = self.addr_index.get(str(t.destinationAddress))
            a = per_pair.setdefault((s, d), [0, 0, 0.0])
            a[0] += dtx
            a[1] += drx
            a[2] += dd
            tot_tx += dtx
            tot_rx += drx
            tot_delay += dd
            tot_bytes += db
        return {"tx": tot_tx, "rx": tot_rx, "delay_sum": tot_delay,
                "rx_bytes": tot_bytes, "per_pair": per_pair}

    def close(self):
        ns.core.Simulator.Destroy()

"""
Section 4.2 - Load-balanced CH selection (solution encoding Fig. 3, fitness Eqs. 7-22).

A candidate is a 1 x k vector in [LB, UB]; each entry is mapped to the index of a
CH among the alive UAVs (duplicates repaired).  Members join the in-range CH with
the longest link lifetime (nearest CH if none is in range).

Each objective is normalised to [0, 1] so it can enter Eq. (22):
  F = w1 F1 + w2(1-F2) + w3(1-F3) + w4 F4 + w5 F5 + w6(1-F6) + w7 F7 + w8(1-F8) + w9 F9 + w10 F10
and the optimiser MINIMISES -F.
  F1 energy (Eq. 7-10)       F2 distance (Eq. 11-13)   F3 delay (Eq. 14)
  F4 load (Eq. 15)           F5 NLI (Eq. 16)           F6 LBF (Eq. 17)
  F7 energy balance (Eq. 18) F8 ICC (Eq. 19)           F9 connectivity (Eq. 20)
  F10 link lifetime (Eq. 21)
"""
import numpy as np

OBJ_NAMES = ["F1_energy", "F2_distance", "F3_delay", "F4_load", "F5_NLI",
             "F6_LBF", "F7_energy_balance", "F8_ICC", "F9_connectivity", "F10_link_lifetime"]


class CHSelectionProblem(object):
    def __init__(self, idx, D, LET, energy_norm, bs, R, k, weights, let_cap, t_max_factor=1.5):
        self.idx = np.asarray(idx)
        self.n = len(idx)
        self.k = int(max(1, min(k, self.n - 1)))
        self.D = D[np.ix_(self.idx, self.idx)]
        self.L = LET[np.ix_(self.idx, self.idx)]
        self.dbs = D[self.idx, bs]
        self.e = energy_norm[self.idx]
        self.R = R
        self.w = np.asarray(weights, float)
        self.let_cap = let_cap
        self.t_max_factor = t_max_factor
        self.mean_d = self.D.sum(1) / max(self.n - 1, 1)
        self.D_lambda = (self.mean_d + self.dbs).sum()

    # ---- solution encoding (Fig. 3) ----
    def decode(self, x):
        raw = np.clip((np.asarray(x) * self.n).astype(int), 0, self.n - 1)
        used, chs = set(), []
        for r in raw:
            j = int(r)
            step = 1
            while j in used:                       # repair duplicates with nearest free index
                for c in (r + step, r - step):
                    if 0 <= c < self.n and int(c) not in used:
                        j = int(c)
                        break
                step += 1
            used.add(j)
            chs.append(j)
        return np.array(chs, int)

    def assign(self, chs):
        mask = np.ones(self.n, bool)
        mask[chs] = False
        members = np.where(mask)[0]
        Dm = self.D[np.ix_(members, chs)]
        Lm = self.L[np.ix_(members, chs)]
        inr = Dm <= self.R
        has = inr.any(1)
        a = np.where(has, np.argmax(np.where(inr, Lm, -1.0), 1), np.argmin(Dm, 1))
        return members, a, Dm[np.arange(len(members)), a], Lm[np.arange(len(members)), a], has

    def objectives(self, chs):
        members, a, d, let, inr = self.assign(chs)
        k = len(chs)
        e_ch = self.e[chs]
        e_m = self.e[members]
        nm = max(len(members), 1)
        # F1 energy (Eq. 7-10), oriented so that higher = CHs/members with more energy
        e_lam = max(e_m.max() if len(e_m) else 1.0, 1e-9) * max(e_ch.max(), 1e-9)
        Eh = np.sum(1.0 - e_m * e_ch[a])
        F1 = np.clip(1.0 - Eh / (nm * e_lam), 0, 1) if len(members) else 1.0
        # F2 distance (Eq. 11-13)
        Dh = np.sum(d + self.dbs[chs][a])
        F2 = np.clip(Dh / max(self.D_lambda, 1e-9), 0, 1)
        # cluster sizes (including the CH)
        sizes = np.bincount(a, minlength=k) + 1
        F3 = sizes.max() / float(self.n)                                    # Eq. 14
        F4 = inr.mean() if len(members) else 1.0                            # Eq. 15
        F5 = e_ch.mean()                                                    # Eq. 16
        t_avg = self.n / float(k)
        t_max = np.ceil(self.t_max_factor * t_avg)
        F6 = np.clip(np.mean(np.abs(sizes - t_avg)) / t_max, 0, 1)          # Eq. 17
        F7 = 1.0 - np.clip(e_ch.std() / (e_ch.mean() + 1e-9), 0, 1)         # Eq. 18
        F8 = np.clip(np.mean(d ** 2) / self.R ** 2, 0, 1) if len(members) else 0.0  # Eq. 19
        F9 = np.mean(np.where(inr, 1.0 - d / self.R, 0.0)) if len(members) else 1.0  # Eq. 20
        F10 = np.mean(let) / self.let_cap if len(members) else 1.0          # Eq. 21
        return np.array([F1, F2, F3, F4, F5, F6, F7, F8, F9, F10])

    def score(self, F):
        terms = np.array([F[0], 1 - F[1], 1 - F[2], F[3], F[4], 1 - F[5], F[6], 1 - F[7], F[8], F[9]])
        return float(self.w @ terms)                                        # Eq. 22

    def fitness(self, x):
        return -self.score(self.objectives(self.decode(x)))


def select_cluster_heads(optimizer, idx, D, LET, energy_norm, bs, R, k, cfg, rng):
    prob = CHSelectionProblem(idx, D, LET, energy_norm, bs, R, k, cfg.FITNESS_WEIGHTS,
                              cfg.LET_CAP, cfg.T_MAX_FACTOR)
    best_x, best_f, curve = optimizer(prob.fitness, prob.k, cfg.LB, cfg.UB, cfg.POP_SIZE,
                                      cfg.MAX_ITER, rng=rng, alpha=cfg.ALPHA, const=cfg.CONST,
                                      beta=cfg.BETA, quantize=1.0 / prob.n)
    chs_local = prob.decode(best_x)
    members, a, d, let, inr = prob.assign(chs_local)
    F = prob.objectives(chs_local)
    ch_of = {int(idx[c]): int(idx[c]) for c in chs_local}
    for m, j in zip(members, a):
        ch_of[int(idx[m])] = int(idx[chs_local[j]])
    return {
        "chs": idx[chs_local],
        "ch_of": ch_of,
        "objectives": F,
        "fitness": prob.score(F),
        "curve": curve,
        "member_dist": d,
        "member_let": let,
        "member_inrange": inr,
    }

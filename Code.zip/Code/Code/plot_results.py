#!/usr/bin/env python3
"""
Figures from run_experiments.py outputs:
  plots/<metric>_vs_rounds_N<n>.png/.svg   (one line per method)
  plots/<metric>_vs_nodes_R<r>.png/.svg    (grouped bars per method)
  plots/topology_<...>.png                 (Fig. 4 style snapshots)
  plots/<metric>_*.csv                     values plotted in each figure
"""
import argparse
import glob
import json
import os

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

plt.rcParams.update({"font.family": "sans-serif", "font.weight": "bold",
                     "axes.labelweight": "bold", "axes.titleweight": "bold"})

METRICS = {
    "energy_J": "Energy consumption (J)",
    "delay_ms": "Delay (ms)",
    "distance_m": "Distance (m)",
    "node_degree": "Node degree",
    "link_lifetime_s": "Link lifetime (s)",
    "icc": "ICC",
    "pdr": "Packet delivery ratio",
    "throughput_kbps": "Throughput (kbps)",
    "alive": "Alive nodes",
    "lbf": "Load balance factor",
}
COLORS = ["#1f77b4", "#ff7f0e", "#2ca02c", "#d62728", "#9467bd", "#8c564b", "#e377c2"]
MARKERS = ["o", "s", "^", "D", "*", "P", "X"]


def order_methods(ms):
    ms = list(ms)
    if "CCRA" in ms:                       # proposed method last
        ms.remove("CCRA")
        ms.append("CCRA")
    return ms


def style(ax, xl, yl):
    ax.set_xlabel(xl, fontsize=11)
    ax.set_ylabel(yl, fontsize=11)
    ax.grid(True, linestyle="--", alpha=0.5, color="#cccccc")
    ax.spines["top"].set_visible(False)
    ax.spines["right"].set_visible(False)
    ax.legend(loc="lower center", bbox_to_anchor=(0.5, -0.32), ncol=3, fontsize=8.5,
              frameon=True, edgecolor="#cccccc")


def save(fig, base):
    fig.tight_layout()
    fig.savefig(base + ".png", dpi=300, bbox_inches="tight")
    fig.savefig(base + ".svg", bbox_inches="tight")
    plt.close(fig)


def label(m, eng):
    return "Proposed CCRA" if m == "CCRA" else m


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--results", default="results")
    a = ap.parse_args()
    out = os.path.join(a.results, "plots")
    os.makedirs(out, exist_ok=True)

    p = os.path.join(a.results, "summary_vs_rounds.csv")
    if os.path.exists(p):
        s = pd.read_csv(p)
        for eng, se in s.groupby("engine"):
            methods = order_methods(se["method"].unique())
            suffix = "" if eng == "ns3" else "_" + eng
            # metric vs rounds, one figure per node count
            for n, sn in se.groupby("nodes"):
                for col, yl in METRICS.items():
                    piv = sn.pivot_table(index="rounds", columns="method", values=col)
                    piv = piv[[m for m in methods if m in piv.columns]]
                    fig, ax = plt.subplots(figsize=(6, 6))
                    for i, m in enumerate(piv.columns):
                        ax.plot(piv.index, piv[m], marker=MARKERS[i % 7], color=COLORS[i % 7],
                                linewidth=2.2, markersize=6.5, label=label(m, eng))
                    ax.set_xticks(piv.index)
                    style(ax, "Number of rounds", yl)
                    base = os.path.join(out, "%s_vs_rounds_N%d%s" % (col, n, suffix))
                    piv.to_csv(base + ".csv")
                    save(fig, base)
            # metric vs nodes at the largest round count
            R = se["rounds"].max()
            sr = se[se["rounds"] == R]
            for col, yl in METRICS.items():
                piv = sr.pivot_table(index="nodes", columns="method", values=col)
                piv = piv[[m for m in methods if m in piv.columns]]
                fig, ax = plt.subplots(figsize=(6, 6))
                x = np.arange(len(piv.index))
                bw = 0.8 / max(len(piv.columns), 1)
                for i, m in enumerate(piv.columns):
                    ax.bar(x + i * bw, piv[m], width=bw, color=COLORS[i % 7], edgecolor="black",
                           linewidth=0.8, label=label(m, eng))
                ax.set_xticks(x + bw * (len(piv.columns) - 1) / 2)
                ax.set_xticklabels(piv.index)
                style(ax, "Number of nodes", yl)
                base = os.path.join(out, "%s_vs_nodes_R%d%s" % (col, R, suffix))
                piv.to_csv(base + ".csv")
                save(fig, base)

    # topology snapshots (Fig. 4 style)
    for jf in sorted(glob.glob(os.path.join(a.results, "raw", "topology_*.json"))):
        t = json.load(open(jf))
        pos = np.array(t["pos"])
        alive = np.array(t["alive"])
        bs, chs, sch = t["bs"], set(t["chs"]), t["sch"]
        fig, ax = plt.subplots(figsize=(7, 7))
        n = len(pos) - 1
        for i in range(n):
            if not alive[i]:
                continue
            for j in range(i + 1, n):
                if alive[j] and np.linalg.norm(pos[i] - pos[j]) <= t["range"]:
                    ax.plot(pos[[i, j], 0], pos[[i, j], 1], color="#bbbbbb", lw=0.4, zorder=1)
        for path in t["backbone"]:
            ax.plot(pos[path, 0], pos[path, 1], color="red", lw=2.0, zorder=3)
        normal = [i for i in range(n) if alive[i] and i not in chs]
        ax.scatter(pos[normal, 0], pos[normal, 1], c="#2ca02c", s=25, label="UAV node", zorder=4)
        ch_list = [c for c in chs if c != sch]
        ax.scatter(pos[ch_list, 0], pos[ch_list, 1], marker="s", c="#1f77b4", s=80,
                   edgecolors="black", label="CH", zorder=5)
        ax.scatter(pos[sch, 0], pos[sch, 1], marker="*", c="orange", s=350,
                   edgecolors="black", label="SCH", zorder=6)
        ax.scatter(pos[bs, 0], pos[bs, 1], marker="^", c="green", s=250,
                   edgecolors="black", label="BS", zorder=6)
        ax.set_title("Round %d (%s)" % (t["round"], t["method"]))
        ax.set_xlabel("X (m)")
        ax.set_ylabel("Y (m)")
        ax.set_aspect("equal")
        ax.legend(loc="upper right", fontsize=8)
        save(fig, os.path.join(out, os.path.splitext(os.path.basename(jf))[0]))
    print("plots saved in", os.path.abspath(out))


if __name__ == "__main__":
    main()

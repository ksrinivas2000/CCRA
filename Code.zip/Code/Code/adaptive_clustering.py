"""
Section 4.1 - FANET cluster formation with adaptive clustering (Algorithm 1).

Merit value (Eq. 1) = weighted sum of
  remaining energy, centrality, neighbour degree, speed similarity, link validity time.
Step 1  leader selection   : node with the highest merit among its neighbours (Eq. 2-3)
Step 2  joining a cluster  : one leader -> join; several -> longest link validity time;
                             none -> declare itself leader (Eq. 4-5, modes 1-3)
Step 3  gateway selection  : members with a neighbour in another cluster (Eq. 6)
"""
import numpy as np

MERIT_WEIGHTS = (0.30, 0.20, 0.20, 0.15, 0.15)


def merit_values(idx, D, LET, vel, energy_norm, R, let_cap, vmax, weights=MERIT_WEIGHTS):
    n = len(idx)
    Dl = D[np.ix_(idx, idx)]
    A = (Dl <= R) & ~np.eye(n, dtype=bool)
    deg = A.sum(1).astype(float)
    with np.errstate(invalid="ignore", divide="ignore"):
        mean_d = np.where(deg > 0, (Dl * A).sum(1) / np.maximum(deg, 1), R)
        centrality = 1.0 - mean_d / R
        V = vel[idx]
        dv = np.linalg.norm(V[:, None, :] - V[None, :, :], axis=-1)
        sim = np.where(deg > 0, 1.0 - (dv * A).sum(1) / np.maximum(deg, 1) / (2 * vmax), 0.0)
        lvt = np.where(deg > 0, (LET[np.ix_(idx, idx)] * A).sum(1) / np.maximum(deg, 1) / let_cap, 0.0)
    degn = deg / max(deg.max(), 1.0)
    feats = np.vstack([energy_norm[idx], centrality, degn, np.clip(sim, 0, 1), lvt])
    return np.asarray(weights) @ feats, A, deg


def form_clusters(idx, D, LET, vel, energy_norm, R, let_cap, vmax):
    """Returns dict with leaders (global ids), cluster_of (global->leader), gateways, ctrl msg counts."""
    n = len(idx)
    M, A, deg = merit_values(idx, D, LET, vel, energy_norm, R, let_cap, vmax)
    Ll = LET[np.ix_(idx, idx)]
    key = M + 1e-9 * (n - np.arange(n))               # deterministic tie-break
    is_leader = np.array([key[i] >= key[A[i]].max() if A[i].any() else True for i in range(n)])
    leader_of = -np.ones(n, int)
    leader_of[is_leader] = np.where(is_leader)[0]
    ctrl_tx = np.ones(n)                               # merit message (Eq. 2)
    ctrl_tx[is_leader] += 1                            # leader message (Eq. 3)

    for i in np.argsort(-key):                         # step 2, highest merit first
        if leader_of[i] >= 0:
            continue
        cand = np.where(A[i] & is_leader)[0]
        if len(cand) == 1:                             # mode 1
            leader_of[i] = cand[0]
        elif len(cand) > 1:                            # mode 2: longest link validity time
            leader_of[i] = cand[np.argmax(Ll[i, cand])]
        else:                                          # mode 3: become a leader
            is_leader[i] = True
            leader_of[i] = i
            ctrl_tx[i] += 1
            continue
        ctrl_tx[i] += 1                                # connection message (Eq. 4)
        ctrl_tx[leader_of[i]] += 1                     # accept message (Eq. 5)

    gateways = []
    for i in range(n):                                 # step 3: hello + gateway (Eq. 6)
        ctrl_tx[i] += 1
        if not is_leader[i] and np.any(A[i] & (leader_of != leader_of[i])):
            gateways.append(idx[i])
            ctrl_tx[i] += 1
    return {
        "leaders": idx[np.where(is_leader)[0]],
        "cluster_of": {int(idx[i]): int(idx[leader_of[i]]) for i in range(n)},
        "gateways": np.array(gateways, int),
        "ctrl_tx": ctrl_tx,                            # per local node
        "degree": deg,
        "merit": M,
    }

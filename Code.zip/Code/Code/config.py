"""
Simulation parameters.

Values marked [T1] come from Table 1 of the manuscript; everything else is a
default chosen for this implementation and can be changed here.
"""

# ---------------- Network / scenario ----------------
AREA_X = 500.0                 # [T1] 500 x 500 m
AREA_Y = 500.0
ALT_MIN = 60.0                 # UAV flight altitude band (m)
ALT_MAX = 100.0
BS_POS = (250.0, 250.0, 0.0)   # ground base station
COMM_RANGE = 120.0             # [T1] communication range (m)
INITIAL_ENERGY = 100.0         # [T1] J per UAV
N_NODES = 100                  # [T1] default number of UAVs
N_ROUNDS = 500                 # [T1] default number of rounds
ROUND_TIME = 2.0               # simulated seconds per round

# Gauss-Markov 3D mobility
SPEED_MIN = 5.0                # m/s
SPEED_MAX = 15.0
GM_ALPHA = 0.85
GM_TIMESTEP = 0.5              # s

# ---------------- Radio ----------------
DATA_RATE_BPS = 1e6            # [T1] 1 Mbps
WIFI_MODE = "DsssRate1Mbps"    # 802.11b 1 Mbps in ns-3
PROP_SPEED = 3e8               # [T1] speed of light
E_ELEC = 50e-9                 # [T1] 50 nJ/bit (tx/rx electronics)
EPS_FS = 10e-12                # free-space amplifier, J/bit/m^2
EPS_MP = 0.0013e-12            # multipath amplifier, J/bit/m^4
E_DA = 5e-9                    # data aggregation, J/bit

# ---------------- Traffic per round ----------------
PKTS_PER_ROUND = 2             # packets each source sends per round
MEMBER_PKT_BYTES = 256         # member -> CH payload
CH_PKT_BYTES = 512             # CH -> SCH and SCH -> BS aggregated payload
HEADER_BYTES = 62              # UDP/IP/MAC overhead counted for energy
CTRL_PKT_BYTES = 32            # clustering control messages

# ---------------- Optimiser (CH selection) ----------------
LB = 0.0                       # [T1]
UB = 1.0                       # [T1]
MAX_ITER = 100                 # [T1]
POP_SIZE = 30                  # [T1]
ALPHA = 0.1                    # [T1] used as Levy/predation step scale in CCO/CCRA
CONST = 0.3                    # [T1] used as adjustment-mechanism probability in CCO/CCRA
BETA = 0.5                     # [T1] used as DRA miracle probability (mp) in CCRA/DRA

# Eq. (22) weights w1..w10 (must sum to 1)
FITNESS_WEIGHTS = [0.1] * 10
T_MAX_FACTOR = 1.5             # max allowable cluster size = factor * average size (Eq. 17)
MIN_CLUSTERS = 2

# Eq. (32): the manuscript's DRA term uses cos(pi/2), which is 0, so the update
# collapses to ~0.  True = implement exactly as written; False = use
# cos(pi/2 * R) so the term is non-zero (see README).
CCRA_LITERAL_EQ32 = True

# ---------------- Routing: multi-agent actor-critic ----------------
ROUTE_HIDDEN = 16              # actor/critic hidden units (Table 1 lists 512; see README)
ROUTE_LR = 0.01                # [T1] critic learning rate
ROUTE_BATCH = 32               # [T1]
ROUTE_EPOCHS = 100             # [T1]
ROUTE_GAMMA = 0.95
ROUTE_MAX_HOPS = 15
ROUTE_RETRAIN_EVERY = 25       # re-train actor (with the optimiser) every N rounds
ROUTE_POP = 30
ROUTE_ITER = 100
# reward = -w_dist*distance - w_delay*delay + w_trust*trust  (Section 4.4.1 d)
REWARD_W_DIST = 0.4
REWARD_W_DELAY = 0.3
REWARD_W_TRUST = 0.3

# ---------------- Mamdani SCH selection ----------------
N_SCH = 1                      # number of super cluster heads per round

# ---------------- Misc ----------------
LET_CAP = 100.0                # cap for link-expiration time (s)
SNAPSHOT_ROUNDS = [20, 50]     # topology snapshots (manuscript Fig. 4)

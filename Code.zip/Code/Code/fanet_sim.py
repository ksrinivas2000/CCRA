#!/usr/bin/env python3
"""
One FANET simulation run: CCRA-style load-balanced clustering, fuzzy SCH
selection and actor-critic routing, round by round.

Per round:
  1. read UAV positions/velocities from the engine (ns-3 or python fallback)
  2. adaptive clustering (Sec. 4.1)  -> number of clusters k
  3. load-balanced CH selection with the chosen optimiser (Sec. 4.2, Eq. 22)
  4. SCH selection with the Mamdani FIS (Sec. 4.3)
  5. routing CH -> SCH -> BS with the multi-agent actor-critic (Sec. 4.4),
     actor re-trained by the same optimiser every ROUTE_RETRAIN_EVERY rounds
  6. traffic for the round is simulated; energy, delay, PDR etc. are logged

Run inside ns-3.31:
  ./waf --pyrun "scratch/ccra_fanet/fanet_sim.py --nodes 100 --rounds 500 --method CCRA"
Run without ns-3 (pipeline test only):
  python3 fanet_sim.py --engine python --nodes 50 --rounds 20 --method CCRA
"""
import argparse
import csv
import json
import os
import sys
import time

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

import numpy as np

import config as cfg
from optimizers import get_optimizer
from geometry import distance_matrix, let_matrix
from adaptive_clustering import form_clusters
from ch_selection import select_cluster_heads, OBJ_NAMES
from sch_fuzzy import select_sch, category
from routing_maac import RoutingContext, MAACRouter, bfs_tree_to
from energy_model import round_energy

FIELDS = ["engine", "method", "nodes", "seed", "round", "alive", "n_clusters", "sch",
          "sch_suitability", "sch_category", "energy_round_J", "energy_total_J",
          "avg_residual_J", "delay_ms", "pdr", "throughput_kbps", "distance_m",
          "node_degree", "link_lifetime_s", "icc", "lbf", "avg_route_hops",
          "fitness", "time_s"] + OBJ_NAMES


def make_engine(name, n, seed):
    if name == "ns3":
        from ns3_engine import NS3Engine
        return NS3Engine(n, cfg, seed)
    from py_engine import PyEngine
    return PyEngine(n, cfg, seed)


def walk(routes, src, dst, maxh=30):
    path, cur = [src], src
    while cur != dst and len(path) <= maxh:
        nh = routes.get((cur, dst), dst)
        if nh in path:
            break
        path.append(nh)
        cur = nh
    return path


def simulate(n, rounds, method, engine_name, seed, out_dir, snapshot_rounds=None, verbose=True):
    rng = np.random.default_rng(seed)
    optimizer = get_optimizer(method)
    engine = make_engine(engine_name, n, seed)
    bs = n
    energy = np.full(n + 1, cfg.INITIAL_ENERGY)
    energy[bs] = np.inf
    trust = np.full(n + 1, 1.0)
    router = MAACRouter(cfg, rng)
    vmax = cfg.SPEED_MAX * 1.5
    snapshot_rounds = set(snapshot_rounds if snapshot_rounds is not None else cfg.SNAPSHOT_ROUNDS)

    os.makedirs(out_dir, exist_ok=True)
    tag = "%s_N%d_seed%d_%s" % (method, n, seed, engine.name)
    csv_path = os.path.join(out_dir, "rounds_%s.csv" % tag)
    fh = open(csv_path, "w", newline="")
    writer = csv.DictWriter(fh, fieldnames=FIELDS)
    writer.writeheader()
    e_total = 0.0

    for r in range(1, rounds + 1):
        t0 = time.time()
        pos, vel = engine.state()
        alive = np.zeros(n + 1, bool)
        alive[:n] = energy[:n] > 0
        alive[bs] = True
        idx = np.where(alive[:n])[0]
        if len(idx) < 3:
            if verbose:
                print("round %d: fewer than 3 UAVs alive, stopping" % r)
            break

        D = distance_matrix(pos)
        LET = let_matrix(pos, vel, cfg.COMM_RANGE, cfg.LET_CAP)
        e_norm = np.ones(n + 1)
        e_norm[:n] = np.clip(energy[:n] / cfg.INITIAL_ENERGY, 0, 1)

        # 1) adaptive clustering
        cl = form_clusters(idx, D, LET, vel, e_norm, cfg.COMM_RANGE, cfg.LET_CAP, vmax)
        k = int(np.clip(len(cl["leaders"]), cfg.MIN_CLUSTERS, max(cfg.MIN_CLUSTERS, len(idx) // 3)))

        # 2) load-balanced CH selection
        sel = select_cluster_heads(optimizer, idx, D, LET, e_norm, bs, cfg.COMM_RANGE, k, cfg, rng)
        chs, ch_of = [int(c) for c in sel["chs"]], sel["ch_of"]

        # 3) SCH selection (Mamdani FIS)
        degree_of = {int(g): int(d) for g, d in zip(idx, cl["degree"])}
        schs, suit = select_sch(chs, ch_of, D, e_norm, bs, cfg.COMM_RANGE, degree_of, cfg.N_SCH)
        sch = int(schs[0])

        # 4) routing
        is_ch = np.zeros(n + 1)
        is_ch[chs] = 1.0
        is_ch[cl["gateways"]] = 0.5
        is_ch[bs] = 1.0
        ctx = RoutingContext(D, LET, alive, e_norm, is_ch, trust, cfg.COMM_RANGE, cfg, bs)
        agents = [(c, sch) for c in chs if c != sch] + [(sch, bs)]
        if r == 1 or r % cfg.ROUTE_RETRAIN_EVERY == 0:
            router.train(optimizer, ctx, agents)
        routes = {}
        route_info = router.build_routes(ctx, agents, routes)

        flows = []
        trees = {}
        for m in idx:                                          # members -> CH
            m = int(m)
            c = ch_of[m]
            if m == c:
                continue
            if D[m, c] > cfg.COMM_RANGE:                        # out of range: multi-hop BFS tree
                if c not in trees:
                    trees[c] = bfs_tree_to(ctx.adj, c)
                cur = m
                while cur in trees[c] and trees[c][cur] is not None and (cur, c) not in routes:
                    routes[(cur, c)] = trees[c][cur]
                    cur = trees[c][cur]
            else:
                routes.setdefault((m, c), c)
            flows.append({"src": m, "dst": c, "pkts": cfg.PKTS_PER_ROUND, "bytes": cfg.MEMBER_PKT_BYTES})
        for s, t in agents:                                    # CH -> SCH, SCH -> BS
            flows.append({"src": s, "dst": t, "pkts": cfg.PKTS_PER_ROUND, "bytes": cfg.CH_PKT_BYTES})
        paths = [walk(routes, f["src"], f["dst"]) for f in flows]

        # 5) simulate the round
        stats = engine.run_round(routes, flows, cfg.ROUND_TIME)

        # energy
        ctrl = {int(g): (cl["ctrl_tx"][i], cl["degree"][i]) for i, g in enumerate(idx)}
        E = round_energy(n + 1, flows, paths, D, ctrl, cfg, set(chs))
        E[bs] = 0.0
        E[~alive] = 0.0
        energy[:n] = np.maximum(energy[:n] - E[:n], 0.0)
        e_round = float(E[:n].sum())
        e_total += e_round

        # trust update from per-flow delivery (EWMA)
        for (s, d), (tx, rx, _) in stats["per_pair"].items():
            if s is None or d is None or tx == 0:
                continue
            pdr_f = rx / float(tx)
            for f, p in zip(flows, paths):
                if f["src"] == s and f["dst"] == d:
                    for node in p[1:]:
                        trust[node] = 0.8 * trust[node] + 0.2 * pdr_f
                    break

        # metrics
        Fobj = sel["objectives"]
        A = (D[np.ix_(idx, idx)] <= cfg.COMM_RANGE)
        row = {
            "engine": engine.name, "method": method, "nodes": n, "seed": seed, "round": r,
            "alive": int(len(idx)), "n_clusters": len(chs), "sch": sch,
            "sch_suitability": round(suit[sch], 4), "sch_category": category(suit[sch]),
            "energy_round_J": e_round, "energy_total_J": e_total,
            "avg_residual_J": float(energy[:n].mean()),
            "delay_ms": 1000.0 * stats["delay_sum"] / stats["rx"] if stats["rx"] else float("nan"),
            "pdr": stats["rx"] / float(stats["tx"]) if stats["tx"] else float("nan"),
            "throughput_kbps": stats["rx_bytes"] * 8.0 / cfg.ROUND_TIME / 1000.0,
            "distance_m": float(np.mean(sel["member_dist"])) if len(sel["member_dist"]) else 0.0,
            "node_degree": float(A.sum(1).mean() - 1),
            "link_lifetime_s": float(np.mean(sel["member_let"])) if len(sel["member_let"]) else 0.0,
            "icc": float(Fobj[7]), "lbf": float(Fobj[5]),
            "avg_route_hops": float(np.mean([len(p) - 1 for p, _ in route_info.values()])),
            "fitness": sel["fitness"], "time_s": time.time() - t0,
        }
        row.update({k_: float(v) for k_, v in zip(OBJ_NAMES, Fobj)})
        writer.writerow(row)
        fh.flush()

        if r in snapshot_rounds:
            snap = {"round": r, "method": method, "engine": engine.name,
                    "pos": pos.tolist(), "alive": alive.tolist(), "bs": bs,
                    "chs": chs, "sch": sch, "ch_of": {str(a): b for a, b in ch_of.items()},
                    "routes": [[a, b] for (a, _), b in routes.items()],
                    "backbone": [p for p, _ in route_info.values()],
                    "range": cfg.COMM_RANGE}
            with open(os.path.join(out_dir, "topology_%s_r%d.json" % (tag, r)), "w") as jf:
                json.dump(snap, jf)

        if verbose and (r == 1 or r % 10 == 0 or r == rounds):
            print("[%s N=%d] round %d/%d alive=%d CH=%d SCH=%d E=%.3fJ delay=%.2fms PDR=%.3f (%.1fs)"
                  % (method, n, r, rounds, len(idx), len(chs), sch, e_round,
                     row["delay_ms"], row["pdr"], row["time_s"]))
            sys.stdout.flush()

    fh.close()
    engine.close()
    return csv_path


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--nodes", type=int, default=cfg.N_NODES)
    ap.add_argument("--rounds", type=int, default=cfg.N_ROUNDS)
    ap.add_argument("--method", default="CCRA", help="PSO | GWO | CCO | DRA | CCRA")
    ap.add_argument("--engine", default="auto", choices=["auto", "ns3", "python"])
    ap.add_argument("--seed", type=int, default=1)
    ap.add_argument("--out", default="results/raw")
    ap.add_argument("--pop", type=int, help="override POP_SIZE")
    ap.add_argument("--iters", type=int, help="override MAX_ITER")
    ap.add_argument("--quiet", action="store_true")
    a = ap.parse_args()

    if a.pop:
        cfg.POP_SIZE = cfg.ROUTE_POP = a.pop
    if a.iters:
        cfg.MAX_ITER = cfg.ROUTE_ITER = a.iters
    engine = a.engine
    if engine == "auto":
        try:
            import ns.core  # noqa: F401
            engine = "ns3"
        except ImportError:
            engine = "python"
            print("ns-3 Python bindings not found -> using the python fallback engine (test only)")
    path = simulate(a.nodes, a.rounds, a.method, engine, a.seed, a.out, verbose=not a.quiet)
    print("saved", path)


if __name__ == "__main__":
    main()

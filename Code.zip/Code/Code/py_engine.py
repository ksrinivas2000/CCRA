"""
Pure-Python fallback engine with the same interface as ns3_engine.NS3Engine.

Use it only to test the pipeline on a machine without ns-3; results produced
with it are NOT ns-3 results (every output row is tagged engine=python).
Mobility: 3D Gauss-Markov.  Delivery: a hop succeeds if the link is still in
range at mid-round, with a contention-dependent loss.  Delay: per-hop
transmission + propagation + contention approximation.
"""
import numpy as np

from geometry import distance_matrix


class PyEngine(object):
    name = "python"

    def __init__(self, n_uav, cfg, seed=1):
        self.cfg = cfg
        self.n = n_uav
        self.rng = np.random.default_rng(seed)
        r = self.rng
        self.pos = np.zeros((n_uav + 1, 3))
        self.pos[:n_uav, 0] = r.uniform(0, cfg.AREA_X, n_uav)
        self.pos[:n_uav, 1] = r.uniform(0, cfg.AREA_Y, n_uav)
        self.pos[:n_uav, 2] = r.uniform(cfg.ALT_MIN, cfg.ALT_MAX, n_uav)
        self.pos[n_uav] = cfg.BS_POS
        self.mean_speed = r.uniform(cfg.SPEED_MIN, cfg.SPEED_MAX, n_uav)
        self.speed = self.mean_speed.copy()
        self.mean_dir = r.uniform(0, 2 * np.pi, n_uav)
        self.dir = self.mean_dir.copy()
        self.pitch = np.zeros(n_uav)
        self.vel = np.zeros((n_uav + 1, 3))
        self._update_vel()

    def _update_vel(self):
        n = self.n
        self.vel[:n, 0] = self.speed * np.cos(self.dir) * np.cos(self.pitch)
        self.vel[:n, 1] = self.speed * np.sin(self.dir) * np.cos(self.pitch)
        self.vel[:n, 2] = self.speed * np.sin(self.pitch)

    def _step(self, dt):
        c, r, n = self.cfg, self.rng, self.n
        a = c.GM_ALPHA
        s = np.sqrt(1 - a * a)
        self.speed = a * self.speed + (1 - a) * self.mean_speed + s * r.normal(0, 1, n)
        self.speed = np.clip(self.speed, 0, c.SPEED_MAX * 1.5)
        self.dir = a * self.dir + (1 - a) * self.mean_dir + s * r.normal(0, 0.3, n)
        self.pitch = a * self.pitch + s * r.normal(0, 0.05, n)
        self._update_vel()
        self.pos[:n] += self.vel[:n] * dt
        lo = np.array([0, 0, c.ALT_MIN])
        hi = np.array([c.AREA_X, c.AREA_Y, c.ALT_MAX])
        for k in range(3):                                   # reflect at the box walls
            below, above = self.pos[:n, k] < lo[k], self.pos[:n, k] > hi[k]
            self.pos[:n, k] = np.where(below, 2 * lo[k] - self.pos[:n, k], self.pos[:n, k])
            self.pos[:n, k] = np.where(above, 2 * hi[k] - self.pos[:n, k], self.pos[:n, k])
            if k < 2:
                flip = below | above
                self.dir[flip] = (np.pi - self.dir[flip]) if k == 0 else -self.dir[flip]
                self.mean_dir[flip] = self.dir[flip]
            else:
                self.pitch[below | above] *= -1
        self._update_vel()

    def state(self):
        return self.pos.copy(), self.vel.copy()

    def _advance(self, duration):
        steps = max(1, int(round(duration / self.cfg.GM_TIMESTEP)))
        for _ in range(steps):
            self._step(duration / steps)

    def run_round(self, routes, flows, duration):
        c = self.cfg
        self._advance(duration / 2.0)
        D = distance_matrix(self.pos)
        A = D <= c.COMM_RANGE
        deg = A.sum(1) - 1
        per_pair = {}
        tot_tx = tot_rx = 0
        tot_delay = 0.0
        tot_bytes = 0
        for f in flows:
            path = [f["src"]]
            cur = f["src"]
            ok = True
            while cur != f["dst"] and len(path) < 30:
                nh = routes.get((cur, f["dst"]), f["dst"])
                if not A[cur, nh]:
                    ok = False
                    break
                path.append(nh)
                cur = nh
            ok = ok and cur == f["dst"]
            bits = (f["bytes"] + c.HEADER_BYTES) * 8.0
            t_tx = bits / c.DATA_RATE_BPS
            hops = len(path) - 1
            p_hop = np.clip(1.0 - 0.01 * deg[path[1:]], 0.7, 1.0) if hops else np.array([1.0])
            p_ok = float(np.prod(p_hop)) if ok else 0.0
            rx = int(self.rng.binomial(f["pkts"], p_ok))
            delay = sum(t_tx * (1 + 0.5 * self.rng.random() * deg[b]) + D[a, b] / c.PROP_SPEED
                        for a, b in zip(path[:-1], path[1:]))
            a = per_pair.setdefault((f["src"], f["dst"]), [0, 0, 0.0])
            a[0] += f["pkts"]
            a[1] += rx
            a[2] += rx * delay
            tot_tx += f["pkts"]
            tot_rx += rx
            tot_delay += rx * delay
            tot_bytes += rx * f["bytes"]
        self._advance(duration / 2.0)
        return {"tx": tot_tx, "rx": tot_rx, "delay_sum": tot_delay,
                "rx_bytes": tot_bytes, "per_pair": per_pair}

    def close(self):
        pass
